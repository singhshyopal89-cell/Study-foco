package com.prince.cbsefocus.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [SubjectEntity::class, ChapterEntity::class, StudyTaskEntity::class],
    version = 1,
    exportSchema = true
)
abstract class StudyDatabase : RoomDatabase() {
    abstract fun studyDao(): StudyDao
}
