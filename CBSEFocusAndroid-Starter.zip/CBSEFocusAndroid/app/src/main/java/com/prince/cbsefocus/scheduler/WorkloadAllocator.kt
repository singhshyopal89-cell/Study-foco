package com.prince.cbsefocus.scheduler

import java.time.LocalDate

data class PendingChapter(
    val id: Long,
    val remainingMinutes: Int,
    val priority: Double
)

data class DayCapacity(
    val date: LocalDate,
    val availableMinutes: Int
)

data class PlannedChunk(
    val chapterId: Long,
    val date: LocalDate,
    val minutes: Int
)

/**
 * Greedy capacity allocator. It preserves every minute of workload provided
 * enough total capacity exists. Revision/mock capacity should be removed from
 * each day's availableMinutes before calling this function.
 */
object WorkloadAllocator {
    fun distribute(
        chapters: List<PendingChapter>,
        days: List<DayCapacity>
    ): List<PlannedChunk> {
        val pending = chapters
            .sortedByDescending { it.priority }
            .associate { it.id to it.remainingMinutes }
            .toMutableMap()

        val output = mutableListOf<PlannedChunk>()

        for (day in days.sortedBy { it.date }) {
            var capacity = day.availableMinutes.coerceAtLeast(0)

            for (chapter in chapters.sortedByDescending { it.priority }) {
                if (capacity == 0) break
                val remaining = pending[chapter.id] ?: 0
                if (remaining <= 0) continue

                val chunk = minOf(remaining, capacity)
                output += PlannedChunk(chapter.id, day.date, chunk)
                pending[chapter.id] = remaining - chunk
                capacity -= chunk
            }
        }
        return output
    }

    fun isFeasible(
        chapters: List<PendingChapter>,
        days: List<DayCapacity>
    ): Boolean {
        val workload = chapters.sumOf { it.remainingMinutes.coerceAtLeast(0) }
        val capacity = days.sumOf { it.availableMinutes.coerceAtLeast(0) }
        return workload <= capacity
    }
}
