package com.prince.cbsefocus

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.prince.cbsefocus.focus.FocusForegroundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme {
                FocusHome(
                    onStart = {
                        val intent = Intent(this, FocusForegroundService::class.java)
                            .setAction(FocusForegroundService.ACTION_START)
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent)
                        else startService(intent)
                    },
                    onStop = {
                        stopService(Intent(this, FocusForegroundService::class.java))
                    }
                )
            }
        }
    }
}

@Composable
private fun FocusHome(onStart: () -> Unit, onStop: () -> Unit) {
    var isRunning by remember { mutableStateOf(false) }
    var remaining by remember { mutableLongStateOf(50 * 60L) }

    LaunchedEffect(isRunning) {
        while (isRunning && remaining > 0) {
            delay(1_000)
            remaining -= 1
        }
        if (remaining == 0L) isRunning = false
    }

    val minutes = remaining / 60
    val seconds = remaining % 60

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("CBSE FOCUS", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("Deep work · 50 minutes", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(28.dp))
            Text(
                "%02d:%02d".format(minutes, seconds),
                style = MaterialTheme.typography.displayLarge
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = {
                        if (!isRunning) {
                            isRunning = true
                            onStart()
                        }
                    },
                    enabled = !isRunning && remaining > 0
                ) { Text("Start focus") }

                OutlinedButton(
                    onClick = {
                        isRunning = false
                        remaining = 50 * 60L
                        onStop()
                    }
                ) { Text("End") }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Starter build: syllabus planner and revision scheduling are the next modules.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
