package com.prince.cbsefocus.scheduler

import java.time.LocalDate

object RevisionPlanner {
    private val intervals = listOf(1L, 3L, 7L, 14L)

    fun revisionDates(completionDate: LocalDate): List<LocalDate> =
        intervals.map(completionDate::plusDays)
}
