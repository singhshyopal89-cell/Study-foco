package com.prince.cbsefocus.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface StudyDao {
    @Insert
    suspend fun addSubject(subject: SubjectEntity): Long

    @Insert
    suspend fun addChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTasks(tasks: List<StudyTaskEntity>)

    @Query("SELECT * FROM subjects ORDER BY name")
    suspend fun getSubjects(): List<SubjectEntity>

    @Query("SELECT * FROM chapters WHERE completed = 0 ORDER BY difficulty DESC")
    suspend fun getPendingChapters(): List<ChapterEntity>

    @Query("SELECT * FROM study_tasks WHERE completed = 0 ORDER BY taskDate")
    suspend fun getPendingTasks(): List<StudyTaskEntity>

    @Query("UPDATE study_tasks SET completed = 1 WHERE id = :taskId")
    suspend fun completeTask(taskId: Long)

    @Transaction
    suspend fun replaceSchedule(tasks: List<StudyTaskEntity>) {
        saveTasks(tasks)
    }
}
