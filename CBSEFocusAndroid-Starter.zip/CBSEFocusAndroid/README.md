# CBSE Focus — Android starter project

Native Android starter for a Class 10 study planner.

## Included
- Kotlin + Jetpack Compose starter dashboard
- User-started foreground focus notification
- Room entities and DAO for subjects, chapters and study tasks
- Workload capacity allocator
- Revision interval planner
- GitHub Actions workflow that builds a debug APK in the cloud

## Build in GitHub
1. Create a new GitHub repository.
2. Upload the contents of this project to the repository root.
3. Open the **Actions** tab and enable GitHub Actions if prompted.
4. Run **Build Android APK**, or push a commit to `main`.
5. Open the successful workflow run.
6. Download `cbse-focus-debug-apk` from **Artifacts**.

The artifact is a debug APK for testing. A release APK requires a signing key and secure signing configuration.

## Android Studio local build
Use JDK 17 and run:

    gradle :app:assembleDebug

## Important scope
This is a starter MVP, not the complete application described in the product specification.
It intentionally does not prevent Settings access, block uninstalling, force maximum volume,
or override user-controlled Android permissions. The timer UI and foreground notification
are starter components; persistent timer-state recovery, the full 50/10 cycle, app reminders,
the complete syllabus UI, transactional rescheduling and mock-exam workflows remain to be built.

## Package
`com.prince.cbsefocus`
